from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.template_filter('datetimeformat')
def datetimeformat(value, format='%Y-%m-%d %H:%M'):
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return value.strftime(format)

# --- Database Setup ---
def init_db():
    with sqlite3.connect('database.db') as conn:
        conn.execute(''' 
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT UNIQUE,
                password TEXT
            )
        ''')
        conn.execute(''' 
            CREATE TABLE IF NOT EXISTS tow_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                location TEXT,
                vehicle_type TEXT,
                contact TEXT,
                issue TEXT,
                status TEXT,
                request_time TEXT
            )
        ''')

init_db()

# --- Routes ---
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        try:
            with sqlite3.connect('database.db') as conn:
                conn.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                             (name, email, hashed_password))
            flash('Registration successful! Please log in.', 'success')
            return redirect('/login')
        except sqlite3.IntegrityError:
            flash('Email already registered.', 'danger')
            return redirect('/register')

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        with sqlite3.connect('database.db') as conn:
            user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()

        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['user_name'] = user[1]
            return redirect('/request_tow')
        else:
            error = 'Invalid email or password.'

    return render_template('login.html', error=error)

@app.route('/request_tow', methods=['GET', 'POST'])
def request_tow():
    if 'user_id' not in session:
        return redirect('/login')

    with sqlite3.connect('database.db') as conn:
        c = conn.cursor()
        c.execute("SELECT name FROM users WHERE id=?", (session['user_id'],))
        name = c.fetchone()[0]

        if request.method == 'POST':
            location = request.form['location']
            vehicle_type = request.form['vehicle_type']
            contact = request.form['contact']
            issue = request.form['issue']
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            c.execute("""INSERT INTO tow_requests 
                         (user_id, location, vehicle_type, contact, issue, status, request_time) 
                         VALUES (?, ?, ?, ?, ?, 'Pending', ?)""",
                      (session['user_id'], location, vehicle_type, contact, issue, timestamp))
            conn.commit()
            return redirect('/my_requests')

    return render_template('request_tow.html', name=name, timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

@app.route('/my_requests')
def my_tow():
    if 'user_id' not in session:
        return redirect('/login')

    with sqlite3.connect('database.db') as conn:
        c = conn.cursor()
        c.execute("SELECT name FROM users WHERE id=?", (session['user_id'],))
        name = c.fetchone()[0]

        c.execute("""SELECT location, vehicle_type, contact, issue, status, request_time 
                     FROM tow_requests WHERE user_id=?""", (session['user_id'],))
        requests = c.fetchall()

    return render_template('my_requests.html', name=name, requests=requests)

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'uday' and password == 'uday123':
            session['admin_logged_in'] = True
            return redirect('/admin')
        flash("Invalid credentials", "danger")
        return redirect('/admin_login')

    return render_template('admin_login.html')

@app.route('/admin')
def admin():
    if 'admin_logged_in' not in session:
        return redirect('/admin_login')

    with sqlite3.connect('database.db') as conn:
        c = conn.cursor()
        c.execute("""
            SELECT users.name, tow_requests.id, tow_requests.location, tow_requests.vehicle_type,
                   tow_requests.contact, tow_requests.issue, tow_requests.status, tow_requests.request_time
            FROM tow_requests
            JOIN users ON tow_requests.user_id = users.id
        """)
        requests = c.fetchall()

    return render_template('admin.html', requests=requests)

@app.route('/update_status/<int:req_id>/<new_status>', methods=['GET', 'POST'])
def update_status(req_id, new_status):
    if 'admin_logged_in' not in session:
        return redirect('/admin_login')

    # Update the status in the database
    with sqlite3.connect('database.db') as conn:
        conn.execute("UPDATE tow_requests SET status=? WHERE id=?", (new_status, req_id))

    # After updating the status, redirect to the correct page
    if 'admin_logged_in' in session:
        return redirect('/admin')  # Admin redirects to admin panel
    else:
        return redirect('/my_requests')  # User redirects to their own requests page


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect('/')
